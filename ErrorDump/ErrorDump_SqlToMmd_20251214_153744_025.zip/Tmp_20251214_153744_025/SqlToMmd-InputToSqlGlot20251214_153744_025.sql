
                CREATE TABLE TestTable1 (
                    ID INT NOT NULL,
                    Name VARCHAR(100),
                    PRIMARY KEY (ID)
                );
                
                CREATE TABLE TestTable2 (
                    ID INT NOT NULL,
                    Table1ID INT,
                    PRIMARY KEY (ID),
                    FOREIGN KEY (Table1ID) REFERENCES TestTable1(ID)
                );
            